#!/bin/sh -

echo INICIANDO Monitor

export LD_LIBRARY_PATH=/opt/sefaz/cco/lib:/opt/sefaz/cco/bin/platforms

sleep 10
/opt/sefaz/cco/bin/Monitor &


