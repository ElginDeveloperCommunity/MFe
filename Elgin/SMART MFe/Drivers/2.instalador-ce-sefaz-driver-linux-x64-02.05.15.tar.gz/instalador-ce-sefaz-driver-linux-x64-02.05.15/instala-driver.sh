#!/bin/bash

#echo logando superusuário
#su

# So o usuario root pode rodar o script
if [[ $EUID -ne 0 ]]; then
   echo "==========================================="
   echo "ATENCAO:"
   echo "Esse script precisa ser executado como root" 1>&2
   echo "==========================================="
   echo
   exit 1
fi

#exit 1
echo "Instalação Driver      MFE 02.05.15"
echo "Instalação Monitor     MFE 01.05.02.028"
echo "Instalação Comunicador MFE 01.05.01.011"
echo "Instalação Biblioteca  MFE 01.05.01.007"
echo "Criando diretorios"

# Desisntala ultima versao
/opt/sefaz/cco/remove-driver.sh

mkdir /opt/sefaz /opt/sefaz/cco /opt/sefaz/drs /opt/sefaz/cco/bin /opt/sefaz/cco/bin/platforms /opt/sefaz/cco/lib
rm -rf /Comunicador/logs

echo "Copiando arquivos"
cp -f ./cco/cco-ser.ini ./cco/Comunicador ./cco/cco-ser ./cco/Monitor ./cco/runcco-mon.sh ./cco/runcco-ser.sh /opt/sefaz/cco/bin
cp -f ./remove-driver.sh /opt/sefaz/cco

echo "Definindo startup para o Monitor"
cp -f ./cco/cco-mon.desktop  /etc/xdg/autostart
#chmod +x ./cco/cco-mon.desktop
#cp ./cco/cco-mon.desktop ~/.config/autostart/


cp -f ./plugins/platforms/*.* /opt/sefaz/cco/bin/platforms
cp -f ./libs_qt/*.*   /opt/sefaz/cco/lib
cp -f ./drs/*.*       /opt/sefaz/drs

echo "Configurando seriais"
cp -f ./cco/80-ttyS-sefaz.rules /etc/udev/rules.d

echo "Dando permissoes"
chmod +x /opt/sefaz/cco/bin/*

sync

echo "Configurando serviço de comunicacao"
cd /etc/local.d
if [ $? -eq 0 ]; then
  #startup no librix
  echo "Configurando serviço de comunicacao"
  ln -sf /opt/sefaz/cco/bin/runcco-ser.sh 03Comunicador.start
  chmod +x 03Comunicador.start

  /opt/sefaz/cco/bin/runcco-ser.sh &
else

  cd /etc/init.d/
  if [ $? -eq 0 ]; then
    echo "Copiando servico"
    cp /opt/sefaz/cco/bin/cco-ser /etc/init.d/
    chmod +x /opt/sefaz/cco/bin/cco-ser
    update-rc.d cco-ser defaults
    if [ $? -eq 0 ]; then
	echo "update-rc.d encontrado"
    else
      cd /etc/rc2.d
      if [ $? -eq 0 ]; then
        echo "/etc/rc2.d encontrado"
        ln -sf /etc/init.d/cco-ser S80cco-ser
      else
        cd /etc/init.d/rc2.d
        if [ $? -eq 0 ]; then
	  echo "/etc/init.d/rc2.d encontrado"
	  ln -sf /etc/init.d/cco-ser S80cco-ser
        fi
      fi
    fi
    echo "Iniciando servico"
    service cco-ser stop
    service cco-ser start
    #/etc/init.d/cco-ser stop
    /opt/sefaz/cco/bin/runcco-mon.sh
    ps aux | grep Comunicador
  else
      echo "Modo de inicialização não identificado!"
  fi
fi
echo "É NECESSÁRIO REINICIAR O SISTEMA PARA AS CONFIGURAÇÕES FAZEREM EFEITO"

#echo monitorando log
#tail -f /var/log/messages | grep cco-ser

