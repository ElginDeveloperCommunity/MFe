#!/bin/sh -

echo INICIANDO Monitor

export LD_LIBRARY_PATH=/opt/sefaz/cco/lib:/opt/sefaz/cco/bin/platforms
export QT_DEBUG_PLUGINS=1

sleep 10
/opt/sefaz/cco/bin/Monitor &


