#!/bin/sh -

echo INICIANDO Comunicador
export LD_LIBRARY_PATH=/opt/sefaz/cco/lib:/opt/sefaz/cco/bin/platforms
  

cd /etc/local.d 
if [ $? -eq 0 ]; then
   echo "Librix" 
  cd /opt/sefaz/cco/bin/
  ./Comunicador &
else
  echo "Normal"
  cd /opt/sefaz/cco/bin/
  ./Comunicador
fi



